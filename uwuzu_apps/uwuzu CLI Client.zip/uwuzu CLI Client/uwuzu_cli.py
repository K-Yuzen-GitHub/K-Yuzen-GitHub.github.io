import json
import requests
import os
import subprocess

version = "v0.1"
ueuse_get = "30"

class Color:
	YELLOW         = '\033[38;2;255;200;50m'#(文字)黄
	RESET          = '\033[0m'#全てリセット

def clear_console():
    subprocess.run('cls' if os.name == 'nt' else 'clear', shell=True)

def set_console_title(title):
    if os.name == 'nt':
        os.system(f"title {title}")
    else:  # Linux/Mac
        print(f"\033]0;{title}\007", end='', flush=True)

set_console_title("uwuzu Python CLI Client")
clear_console()

def clientHome(addres,youToken):
    ueuse_get = input("何件ユーズを取得しますか？\n(半角英数字で入力してください。デフォルトでは30件になっています。最大100件です。)\n取得数: ")
    #print(f"ユーザー: {userName} ({userID})\n")
    clear_console()
    api_url = f'' + addres + f"/api/ueuse?token=" + youToken + f"&limit={ueuse_get}"
    response = requests.get(api_url, headers=headers)
    ueuseJSON = json.loads(response.text)
    #print(ueuseJSON)
    #print("\n\n\n")
    print(f"直近{ueuse_get}件のユーズを取得します。\n")
    for ueuse in ueuseJSON:
        print(f"{Color.YELLOW}{ueuse["account"]["username"]} (@{ueuse["account"]["userid"]}){Color.RESET}:\n{ueuse["text"]} | {ueuse["datetime"]}\nいいね(Favorite): {ueuse["favorite_cnt"]}\n")
    
    input("Enterキーを押すと終了します。")
    exit()

def serverConnectProg(addr):
    token = input(f"\nAPIトークンを入力してください。\n(トークンがない場合は、{server_addres}/others/で発行してください。)\nトークン: ")
    api_url = '' + server_addres + "/api/me?token=" + token
    response = requests.get(api_url, headers=headers)
    apiResponse = response.json()
    userName = apiResponse['username']
    userID = apiResponse['userid']
    userProfile = apiResponse['profile']
    confirm = input(f"{userName}でログインします。よろしいですか？(ID: {userID}) (Y/n)")
    if confirm=="Y" or confirm=="y":
        #confirm = input(f"トークンを保存しますか？ (Y/n)")
        #if confirm=="Y" or confirm=="y":
            
        clientHome(server_addres,token)
    #print(userID)
    #print(userProfile)

headers = {
  'user-agent': 'uwuzuPyCLI'
}
print("uwuzu Command-line Client " + version)
server_addres = input("サーバーアドレスを入力してください。 (例: https://uwuzu.net): ")
api_url = '' + server_addres + '/api/serverinfo-api'

print ("HTTPリクエスト送信先: " + api_url)
response = requests.get(api_url, headers=headers)
apiResponse = response.json()
serverName = apiResponse['server_info']['server_name']
print("")
#print(apiResponse)
#print("")
print(f"サーバー名: {serverName}")
confirm = input(f"{serverName}({server_addres})に接続しますか？ (Y/n)")
if confirm=="Y" or confirm=="y":
    #print("接続中...")
    serverConnectProg(server_addres)
else:
    print("終了します。")
    exit()
